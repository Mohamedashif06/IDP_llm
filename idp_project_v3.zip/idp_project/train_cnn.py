"""
train_cnn.py
-------------
Trains the DigitCNN on real handwritten digit samples and saves the
trained weights to modules/digit_cnn_weights.pt.

DATA SOURCE NOTE: this uses scikit-learn's bundled `load_digits` dataset
(1,797 real handwritten digit samples, 8x8 pixels, ships with the sklearn
package itself — no network download needed). The full MNIST dataset
(60,000 samples, 28x28) would give higher accuracy and is what you should
use for your final submission — it just needs a working internet
connection to download, which your own machine has (this training
environment's network is restricted). To switch to full MNIST, replace
the `load_and_prepare_data()` function below with torchvision's
`datasets.MNIST(...)` call (commented example included).

Run this ONCE (takes under a minute) to produce the trained model file,
which the app then loads for inference — you do not retrain every time
the app runs.

Usage:  python train_cnn.py
"""

import sys
import os
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset
from sklearn.datasets import load_digits
from sklearn.model_selection import train_test_split

sys.path.insert(0, os.path.dirname(__file__))
from modules.cnn_digit_recognizer import DigitCNN


def load_and_prepare_data():
    """Loads sklearn's bundled digit samples and prepares them using the
    EXACT SAME preprocess_digit_cell() function the app uses at inference
    time — this is a deliberate fix for a real bug we hit: normalizing
    training data differently from inference data (training divided by the
    dataset's own max value ~16, inference divided by 255) produced a model
    that scored 97.5% on its own test set but predicted almost randomly on
    realistic input. Reusing ONE preprocessing function for both training
    and inference makes that entire class of bug impossible."""
    from modules.cnn_digit_recognizer import preprocess_digit_cell
    digits = load_digits()
    images = digits.images  # (1797, 8, 8), values 0-16
    labels = digits.target

    # Scale each sample to a realistic 0-255 uint8 image FIRST (matching
    # what a real scanned document cell looks like), THEN run it through
    # the identical preprocessing function inference will use.
    processed = []
    for img in images:
        img_255 = (img * (255.0 / img.max())).astype(np.uint8)
        tensor = preprocess_digit_cell(img_255)  # returns (1, 1, 28, 28)
        processed.append(tensor.squeeze(0))  # -> (1, 28, 28)

    X = torch.stack(processed)
    y = torch.tensor(labels, dtype=torch.long)

    X_train, X_test, y_train, y_test = train_test_split(
        X.numpy(), y.numpy(), test_size=0.2, random_state=42, stratify=labels
    )
    X_train, X_test = torch.tensor(X_train), torch.tensor(X_test)
    y_train, y_test = torch.tensor(y_train, dtype=torch.long), torch.tensor(y_test, dtype=torch.long)

    return X_train, y_train, X_test, y_test

    # --- To use full MNIST instead (recommended for your final submission,
    #     run this on your own machine with internet access): ---
    # from torchvision import datasets, transforms
    # transform = transforms.Compose([transforms.ToTensor()])
    # train_dataset = datasets.MNIST(root="./mnist_data", train=True, download=True, transform=transform)
    # test_dataset = datasets.MNIST(root="./mnist_data", train=False, download=True, transform=transform)
    # (then build DataLoaders from these directly instead of the tensors above)


def train():
    device = torch.device("cpu")
    print(f"Training on: {device}")

    X_train, y_train, X_test, y_test = load_and_prepare_data()
    print(f"Training samples: {len(X_train)}, Test samples: {len(X_test)}")

    train_loader = DataLoader(TensorDataset(X_train, y_train), batch_size=32, shuffle=True)
    test_loader = DataLoader(TensorDataset(X_test, y_test), batch_size=64, shuffle=False)

    model = DigitCNN().to(device)
    optimizer = optim.Adam(model.parameters(), lr=0.001)
    criterion = nn.CrossEntropyLoss()

    epochs = 15  # small dataset, more epochs needed than full MNIST would require
    for epoch in range(epochs):
        model.train()
        total_loss = 0
        for images, labels in train_loader:
            images, labels = images.to(device), labels.to(device)
            optimizer.zero_grad()
            outputs = model(images)
            loss = criterion(outputs, labels)
            loss.backward()
            optimizer.step()
            total_loss += loss.item()
        avg_loss = total_loss / len(train_loader)
        if (epoch + 1) % 5 == 0 or epoch == 0:
            print(f"Epoch {epoch+1}/{epochs} — avg loss: {avg_loss:.4f}")

    # Evaluate on the held-out test set — REAL accuracy, not assumed
    model.eval()
    correct, total = 0, 0
    with torch.no_grad():
        for images, labels in test_loader:
            images, labels = images.to(device), labels.to(device)
            outputs = model(images)
            _, predicted = torch.max(outputs, 1)
            total += labels.size(0)
            correct += (predicted == labels).sum().item()

    accuracy = 100 * correct / total
    print(f"\nTest set accuracy: {accuracy:.2f}% ({correct}/{total} correct)")

    weights_path = os.path.join(os.path.dirname(__file__), "modules", "digit_cnn_weights.pt")
    torch.save(model.state_dict(), weights_path)
    print(f"Saved trained weights to {weights_path}")

    return accuracy


if __name__ == "__main__":
    train()
