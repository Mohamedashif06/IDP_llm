---
title: IDP Document Scanner
emoji: 📄
colorFrom: blue
colorTo: green
sdk: streamlit
sdk_version: "1.38.0"
app_file: app.py
pinned: false
---

# Intelligent Document Processing — Multi-Photo Batch Scanner

Capture/upload documents (forms or dense grid tables) one at a time from
a phone or laptop; each photo's extracted data is appended to one running
Excel file, downloadable at any point.

## Local setup

```bash
python -m venv venv
venv\Scripts\activate        # Windows
source venv/bin/activate     # Mac/Linux
pip install -r requirements.txt
```

Also install the Tesseract OCR binary (see main course guide) — this is
separate from the pip packages above.

## Run locally

```bash
streamlit run app.py
```

## Deploy to Hugging Face Spaces

1. Create a free account at https://huggingface.co
2. Create a New Space → SDK: **Streamlit** → visibility your choice
3. Either:
   - push this whole folder to the Space's git repo (`git remote add space <space-git-url>`, `git push space main`), OR
   - use the Space's web "Files" tab to upload `app.py`, `requirements.txt`,
     `packages.txt`, and the `modules/` folder directly
4. The Space builds automatically (installs `requirements.txt` AND
   `packages.txt` — the latter is what gets Tesseract installed on Hugging
   Face's servers, since it's not a pip package)
5. Once built, your Space gets a public **https://** URL — live mobile
   camera capture (`st.camera_input`) will work correctly here, unlike a
   plain `http://` local network address, because Space URLs are HTTPS
   by default

## Project structure

```
idp_project/
├── app.py                    # Streamlit UI — multi-photo batch mode, Form + Table document types
├── requirements.txt
├── packages.txt               # apt packages for Hugging Face Spaces (Tesseract)
├── modules/
│   ├── preprocessing.py       # image cleanup: deskew, denoise, threshold, quality check
│   ├── ocr_engine.py          # Tesseract wrapper with confidence scoring
│   ├── field_extraction.py    # regex + generic fallback for "Label: Value" form documents
│   ├── table_extractor.py     # grid-line detection + cell-by-cell OCR for dense table documents
│   └── excel_writer.py        # dynamic-column Excel writer, batch-append across multiple photos
├── tests/                     # pytest suite (19 tests)
└── sample_images/
```
