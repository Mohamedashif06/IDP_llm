"""
cnn_digit_recognizer.py
-------------------------
A small CNN for recognizing a SINGLE handwritten digit (0-9) — this is the
narrow, well-scoped use of deep learning from your roadmap (Week 4 stretch
goal), used specifically for handwritten marks cells, NOT as a general
document-reading model.

WHY THIS SCOPE, NOT GENERAL OCR: training a model to read arbitrary
handwritten text/words needs a huge labeled dataset and real compute.
Training a model to recognize a SINGLE digit (10 possible classes) is a
completely different, tractable problem — solvable with the standard MNIST
dataset in minutes on a CPU. This is why we scoped the CNN this narrowly
rather than trying to "solve handwriting" broadly.
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
import cv2


class DigitCNN(nn.Module):
    """Small CNN: 2 conv layers + 2 fully-connected layers. Deliberately
    small — MNIST-scale digit recognition doesn't need a deep network, and
    a smaller model trains faster and runs faster at inference time, which
    matters if you're classifying many mark cells per document."""

    def __init__(self):
        super().__init__()
        self.conv1 = nn.Conv2d(1, 16, kernel_size=3, padding=1)
        self.conv2 = nn.Conv2d(16, 32, kernel_size=3, padding=1)
        self.pool = nn.MaxPool2d(2, 2)
        self.fc1 = nn.Linear(32 * 7 * 7, 64)
        self.fc2 = nn.Linear(64, 10)  # 10 classes: digits 0-9

    def forward(self, x):
        x = self.pool(F.relu(self.conv1(x)))   # 28x28 -> 14x14
        x = self.pool(F.relu(self.conv2(x)))   # 14x14 -> 7x7
        x = x.view(x.size(0), -1)
        x = F.relu(self.fc1(x))
        x = self.fc2(x)
        return x


def preprocess_digit_cell(cell_image: np.ndarray) -> torch.Tensor:
    """Converts a raw cropped cell image (grayscale, any size) into the
    28x28 normalized tensor the model expects — must match MNIST's own
    preprocessing convention (white digit on black background, 0-1 scale)
    or the trained model will perform badly on real cells."""
    resized = cv2.resize(cell_image, (28, 28), interpolation=cv2.INTER_AREA)
    # MNIST convention: white digit (255) on black background (0). Our
    # scanned cells are usually the opposite (black text on white paper)
    # after thresholding, so invert if needed.
    if resized.mean() > 127:
        resized = 255 - resized
    tensor = torch.tensor(resized, dtype=torch.float32) / 255.0
    tensor = tensor.unsqueeze(0).unsqueeze(0)  # add batch + channel dims
    return tensor


def predict_digit(model: DigitCNN, cell_image: np.ndarray) -> dict:
    """Runs inference on one cell, returns the predicted digit AND a
    confidence score — same principle as the OCR confidence scoring
    elsewhere in this project: a low-confidence prediction should be
    flagged for human review, not silently trusted."""
    model.eval()
    tensor = preprocess_digit_cell(cell_image)
    with torch.no_grad():
        logits = model(tensor)
        probs = F.softmax(logits, dim=1)
        confidence, predicted = torch.max(probs, dim=1)
    return {"digit": int(predicted.item()), "confidence": round(float(confidence.item()) * 100, 1)}
