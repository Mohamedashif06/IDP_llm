"""
fuzzy_matching.py
------------------
Maps inconsistent OCR label text ("Roll Number", "Rol1 No", "RollNo") to
your canonical schema field names ("roll_no").

TESTED FINDING (worth knowing): the naive `fuzz.ratio` scorer wrongly
mapped "Studnt Name" to "father_name" instead of "name", because both
canonical strings share the substring "name" and ratio-based scoring gets
confused by that. Switching to `fuzz.WRatio` (a weighted scorer that
handles partial/reordered text better) fixed that case — but every fuzzy
matcher will occasionally produce a low-confidence WRONG match (we saw
"DOB" weakly mismatch at 45%). The fix isn't a "perfect" scorer, it's a
CONFIDENCE THRESHOLD: only auto-accept matches above a cutoff, otherwise
leave the field unmapped for human review rather than silently guessing.
"""

from rapidfuzz import fuzz, process


def normalize_label(label: str) -> str:
    """OCR label text -> a lowercase, underscore-separated string, same
    shape as our canonical field names, so they compare on equal footing."""
    return label.strip().lower().replace(" ", "_").replace(".", "").replace(":", "")


def match_label_to_schema(ocr_label: str, canonical_fields: list, min_confidence: float = 60.0):
    """Tries to map a raw OCR label to the closest canonical field name.

    Returns:
        (matched_field: str | None, confidence: float)
        matched_field is None if no candidate cleared min_confidence —
        this is deliberate: a document with an unmapped field should be
        flagged for human review, not silently assigned to the nearest
        (possibly wrong) canonical field.
    """
    normalized = normalize_label(ocr_label)
    if not canonical_fields:
        return None, 0.0

    match, score, _ = process.extractOne(normalized, canonical_fields, scorer=fuzz.WRatio)
    if score >= min_confidence:
        return match, score
    return None, score


def map_fields_to_schema(extracted_fields: dict, canonical_fields: list, min_confidence: float = 60.0) -> dict:
    """Takes the output of field_extraction.extract_fields() (which may
    contain auto-generated field names from unknown labels — see the
    generic fallback in field_extraction.py) and tries to remap any
    non-canonical field names onto your schema.

    Fields already matching a canonical name exactly are left alone.
    Fields that fuzzy-match with enough confidence get renamed to the
    canonical name (their original name is kept as '<name>_original_label'
    for traceability). Fields that don't confidently match anything are
    left under their original (fallback) name — still saved, just not
    force-fit into your schema.
    """
    result = {}
    for field_name, field_data in extracted_fields.items():
        if field_name in canonical_fields:
            result[field_name] = field_data
            continue

        matched, confidence = match_label_to_schema(field_name, canonical_fields, min_confidence)
        if matched and matched not in result:
            result[matched] = {**field_data, "fuzzy_match_confidence": confidence, "original_label": field_name}
        else:
            # No confident match — keep it under its own name rather than
            # dropping the data or force-mapping it incorrectly.
            result[field_name] = field_data

    return result
