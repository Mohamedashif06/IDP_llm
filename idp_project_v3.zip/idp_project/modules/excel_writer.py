import os
from openpyxl import Workbook, load_workbook


def _get_or_create_workbook(excel_path, sheet_name):
    if os.path.exists(excel_path):
        wb = load_workbook(excel_path)
        if sheet_name not in wb.sheetnames:
            wb.create_sheet(sheet_name)
        ws = wb[sheet_name]
    else:
        wb = Workbook()
        ws = wb.active
        ws.title = sheet_name
    return wb, ws


def _get_header_map(ws):
    header = {}
    for col_idx, cell in enumerate(ws[1], start=1):
        if cell.value:
            header[str(cell.value)] = col_idx
    return header


def append_record(record, excel_path="output/records.xlsx", sheet_name="Records"):
    os.makedirs(os.path.dirname(excel_path) or ".", exist_ok=True)
    wb, ws = _get_or_create_workbook(excel_path, sheet_name)
    header_map = _get_header_map(ws)
    next_col = len(header_map) + 1
    for field_name in record.keys():
        if field_name not in header_map:
            ws.cell(row=1, column=next_col, value=field_name)
            header_map[field_name] = next_col
            next_col += 1
    next_row = ws.max_row + 1 if ws.max_row >= 1 else 2
    if next_row < 2:
        next_row = 2
    for field_name, value in record.items():
        col = header_map[field_name]
        ws.cell(row=next_row, column=col, value=value)
    wb.save(excel_path)
    return {"row_written": next_row, "columns": list(header_map.keys()), "excel_path": excel_path}


def read_all_records(excel_path, sheet_name="Records"):
    if not os.path.exists(excel_path):
        return []
    wb = load_workbook(excel_path)
    if sheet_name not in wb.sheetnames:
        return []
    ws = wb[sheet_name]
    rows = list(ws.iter_rows(values_only=True))
    if not rows:
        return []
    header, data_rows = rows[0], rows[1:]
    records = []
    for row in data_rows:
        if all(v is None for v in row):
            continue
        records.append({header[i]: row[i] for i in range(len(header)) if header[i] is not None})
    return records
