"""
table_extractor.py
--------------------
Extracts data from GRID/TABLE documents (like your CO cycle-test sheet) —
fundamentally different from field_extraction.py, which handles "Label:
Value" style forms.

WHY A SEPARATE APPROACH: whole-page OCR completely fails on a dense table
like your CO sheet (tested — it returned garbage). The table's own grid
lines are actually useful information, not noise: we detect them, use them
to find individual cell boundaries, then OCR each cell separately. Small,
isolated OCR (one cell at a time) is far more accurate than trying to read
an entire table as one block of text.

HONEST LIMITATION: alphanumeric ID cells (e.g. "24UCS022") are the hardest
to read reliably — tested on a real document, roughly 1 in 3 cells in a
dense table needed a human correction. Digit-only mark cells are more
reliable, especially with a digit whitelist, which turns an uncertain guess
into a blank (safely flaggable) rather than a confidently wrong character.
Name cells (longer text) read best of all three types.
This is exactly why the confidence-based review screen matters more for
table documents than for simple forms — budget for it, don't treat it as
optional.
"""

import cv2
import numpy as np
import pytesseract


def detect_grid_lines(gray_image: np.ndarray) -> np.ndarray:
    """Finds the table's own horizontal + vertical lines using morphological
    operations, and returns a binary image containing ONLY those lines.

    How it works: erode-then-dilate with a very WIDE horizontal kernel keeps
    only long horizontal strokes (the row lines) and erases everything else
    (text, noise). Same idea with a very TALL kernel for vertical lines
    (the column lines). Combining both gives us the table's grid structure.
    """
    thresh = cv2.adaptiveThreshold(
        gray_image, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
        cv2.THRESH_BINARY_INV, 15, 10
    )

    h_kernel_len = max(thresh.shape[1] // 30, 10)
    h_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (h_kernel_len, 1))
    horizontal = cv2.dilate(cv2.erode(thresh, h_kernel), h_kernel)

    v_kernel_len = max(thresh.shape[0] // 30, 10)
    v_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (1, v_kernel_len))
    vertical = cv2.dilate(cv2.erode(thresh, v_kernel), v_kernel)

    grid = cv2.add(horizontal, vertical)
    grid = cv2.dilate(grid, np.ones((3, 3), np.uint8))  # close small gaps in the grid
    return grid


def find_cell_boxes(grid_image: np.ndarray, min_w=20, max_w=350, min_h=12, max_h=90) -> list:
    """Finds individual cell rectangles from the detected grid.
    The min/max size filters remove both tiny noise contours and the
    whole-page-sized outer contour, keeping only plausible single cells.
    Tune these if your document's cells are a very different size."""
    contours, _ = cv2.findContours(grid_image, cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)
    boxes = []
    for c in contours:
        x, y, w, h = cv2.boundingRect(c)
        if min_w < w < max_w and min_h < h < max_h:
            boxes.append((x, y, w, h))
    return boxes


def group_boxes_into_rows(boxes: list, y_tolerance: int = 15) -> list:
    """Groups cell boxes into rows by y-position, then sorts each row's
    cells left-to-right by x-position. Returns a list of rows, each row a
    list of (x, y, w, h) tuples, top-to-bottom, left-to-right — i.e. ready
    to treat as an actual table."""
    boxes = sorted(boxes, key=lambda b: b[1])
    rows, used = [], [False] * len(boxes)

    for i, b in enumerate(boxes):
        if used[i]:
            continue
        y_center = b[1] + b[3] / 2
        row = [b]
        used[i] = True
        for j in range(i + 1, len(boxes)):
            if used[j]:
                continue
            if abs((boxes[j][1] + boxes[j][3] / 2) - y_center) < y_tolerance:
                row.append(boxes[j])
                used[j] = True
        row.sort(key=lambda bb: bb[0])
        rows.append(row)

    rows.sort(key=lambda r: r[0][1])
    return rows


def ocr_cell(gray_image: np.ndarray, box: tuple, mode: str = "text") -> str:
    """OCRs a single cell. `mode` controls the OCR configuration:
        "text"   - general short text (names, labels) — psm 7 (single line)
        "digits" - numeric-only cells (marks) — psm 10 (single char) with a
                   digit whitelist. An uncertain guess becomes EMPTY rather
                   than a confidently wrong character — safer for data
                   quality, since an empty result is easy to flag for
                   review, but a wrong-but-plausible character can slip
                   through unnoticed.
        "alnum"  - alphanumeric IDs (roll numbers) — psm 7, no whitelist,
                   since these mix letters and digits.

    Cells are upscaled 3-4x before OCR — table cells are small in the
    original photo, and Tesseract reads small text far worse than the same
    text at a larger size.
    """
    x, y, w, h = box
    pad = 3
    cell = gray_image[max(0, y + pad):y + h - pad, max(0, x + pad):x + w - pad]
    if cell.size == 0:
        return ""

    cell = cv2.resize(cell, None, fx=4, fy=4, interpolation=cv2.INTER_CUBIC)

    if mode == "digits":
        config = "--psm 10 -c tessedit_char_whitelist=0123456789"
    elif mode == "alnum":
        config = "--psm 7"
    else:
        config = "--psm 7"

    text = pytesseract.image_to_string(cell, config=config).strip()
    return text


def extract_table(gray_image: np.ndarray, column_modes: list = None) -> list:
    """Full pipeline: detect grid -> find cells -> group into rows -> OCR
    each cell.

    Args:
        gray_image: preprocessed grayscale (NOT thresholded) image of the
            table. Perspective-correct and deskew BEFORE calling this.
        column_modes: optional list of "text"/"digits"/"alnum" strings, one
            per expected column, applied left-to-right within each row. If
            a row has more cells than column_modes entries, extra cells
            default to "text". If None, every cell uses "text" mode.

    Returns:
        List of rows; each row is a list of OCR'd cell strings, in reading
        order (top-to-bottom, left-to-right) — this is your raw table,
        ready for you to map into named columns using your document's
        known header layout.
    """
    grid = detect_grid_lines(gray_image)
    boxes = find_cell_boxes(grid)
    rows = group_boxes_into_rows(boxes)

    table = []
    for row in rows:
        row_texts = []
        for i, box in enumerate(row):
            mode = column_modes[i] if column_modes and i < len(column_modes) else "text"
            row_texts.append(ocr_cell(gray_image, box, mode=mode))
        table.append(row_texts)

    return table
