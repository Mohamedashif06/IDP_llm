import pytesseract
import numpy as np
import pandas as pd


def run_ocr(image, psm=6):
    config = f"--oem 3 --psm {psm}"
    data = pytesseract.image_to_data(image, config=config, output_type=pytesseract.Output.DATAFRAME)
    data = data[(data.conf != -1)]
    data["text"] = data["text"].astype(str).str.strip()
    data = data[data["text"] != ""]
    if len(data) == 0:
        return {"full_text": "", "words": data, "avg_confidence": 0.0}
    full_text = " ".join(data["text"].tolist())
    avg_confidence = float(data["conf"].astype(float).mean())
    keep_cols = ["text", "conf", "left", "top", "width", "height", "block_num", "par_num", "line_num"]
    return {"full_text": full_text, "words": data[keep_cols].reset_index(drop=True), "avg_confidence": round(avg_confidence, 1)}


def group_words_into_lines(words_df):
    if len(words_df) == 0:
        return []
    lines = []
    grouped = words_df.groupby(["block_num", "par_num", "line_num"], sort=False)
    for _, group in grouped:
        group = group.sort_values("left")
        line_text = " ".join(group["text"].tolist())
        avg_conf = float(group["conf"].astype(float).mean())
        top = int(group["top"].min())
        lines.append({"text": line_text, "avg_confidence": round(avg_conf, 1), "top": top})
    lines.sort(key=lambda l: l["top"])
    return lines
