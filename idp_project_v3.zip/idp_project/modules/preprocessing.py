import cv2
import numpy as np


def to_grayscale(image):
    if len(image.shape) == 3:
        return cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    return image


def denoise(image):
    return cv2.fastNlMeansDenoising(image, h=10, templateWindowSize=7, searchWindowSize=21)


def enhance_contrast(image):
    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
    return clahe.apply(image)


def adaptive_threshold(image, block_size=31, C=15):
    if block_size % 2 == 0:
        block_size += 1
    return cv2.adaptiveThreshold(image, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
                                   cv2.THRESH_BINARY, blockSize=block_size, C=C)


def deskew(image):
    coords = np.column_stack(np.where(image > 0))
    if len(coords) < 50:
        return image
    angle = cv2.minAreaRect(coords)[-1]
    if angle < -45:
        angle = -(90 + angle)
    else:
        angle = -angle
    (h, w) = image.shape[:2]
    center = (w // 2, h // 2)
    M = cv2.getRotationMatrix2D(center, angle, 1.0)
    return cv2.warpAffine(image, M, (w, h), flags=cv2.INTER_CUBIC, borderMode=cv2.BORDER_REPLICATE)


def preprocess_pipeline(image, do_perspective=True, do_denoise=True, do_threshold=True, block_size=31, C=15):
    steps = {}
    working = image.copy()
    steps["perspective_corrected"] = working
    gray = to_grayscale(working)
    steps["grayscale"] = gray
    current = gray
    if do_denoise:
        current = denoise(current)
    steps["denoised"] = current
    current = enhance_contrast(current)
    steps["contrast_enhanced"] = current
    if do_threshold:
        current = adaptive_threshold(current, block_size=block_size, C=C)
    steps["thresholded"] = current
    current = deskew(current)
    steps["final"] = current
    return steps
