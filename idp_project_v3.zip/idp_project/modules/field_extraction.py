import re

FIXED_FIELD_PATTERNS = {
    "roll_no": [r"roll\s*no\.?\s*[:;.,]?\s*([A-Za-z0-9\-\/]+)", r"roll\s*number\s*[:;.,]?\s*([A-Za-z0-9\-\/]+)",
                r"reg(?:istration)?\s*no\.?\s*[:;.,]?\s*([A-Za-z0-9\-\/]+)", r"enroll?ment\s*no\.?\s*[:;.,]?\s*([A-Za-z0-9\-\/]+)",
                r"student\s*id\s*[:;.,]?\s*([A-Za-z0-9\-\/]+)", r"id\s*no\.?\s*[:;.,]?\s*([A-Za-z0-9\-\/]+)"],
    "name": [r"student\s*name\s*[:;.,]?\s*([A-Za-z][A-Za-z\s.]+)", r"candidate\s*name\s*[:;.,]?\s*([A-Za-z][A-Za-z\s.]+)",
             r"name\s*[:;.,]?\s*([A-Za-z][A-Za-z\s.]+)"],
    "father_name": [r"father'?s?\s*name\s*[:;.,]?\s*([A-Za-z][A-Za-z\s.]+)"],
    "department": [r"dep(?:artmen)?t\.?\s*[:;.,]?\s*([A-Za-z&\s]+)", r"branch\s*[:;.,]?\s*([A-Za-z&\s]+)",
                    r"course\s*[:;.,]?\s*([A-Za-z&\s]+)", r"program(?:me)?\s*[:;.,]?\s*([A-Za-z&\s]+)"],
    "class_section": [r"class\s*[:;.,]?\s*([A-Za-z0-9\-\s]+)", r"section\s*[:;.,]?\s*([A-Za-z0-9\-\s]+)"],
    "semester": [r"sem(?:ester)?\s*[:;.,]?\s*([A-Za-z0-9\-\s]+)"],
    "total": [r"total\s*marks?\s*[:;.,]?\s*(\d+)", r"grand\s*total\s*[:;.,]?\s*(\d+)", r"aggregate\s*[:;.,]?\s*(\d+)", r"total\s*[:;.,]?\s*(\d+)"],
    "percentage": [r"percentage\s*[:;.,]?\s*([\d.]+)\s*%?", r"cgpa\s*[:;.,]?\s*([\d.]+)"],
    "date": [r"date\s*(?:of\s*birth)?\s*[:;.,]?\s*(\d{1,2}[\/\-\.]\d{1,2}[\/\-\.]\d{2,4})", r"dob\s*[:;.,]?\s*(\d{1,2}[\/\-\.]\d{1,2}[\/\-\.]\d{2,4})"],
}

SUBJECT_MARK_PATTERN = re.compile(r"subject\s*(\d+)\s*marks?\s*[:;.,]?\s*(\d{1,3})", re.IGNORECASE)
GENERIC_LABEL_VALUE_PATTERN = re.compile(r"^\s*([A-Za-z][A-Za-z\s.]{1,30}?)\s*[:;]\s*(.+?)\s*$")


def _normalize_label(label):
    label = label.strip().lower()
    label = re.sub(r"[^a-z0-9\s]", "", label)
    label = re.sub(r"\s+", "_", label.strip())
    return label


def _try_patterns(line_text, patterns):
    for pattern in patterns:
        m = re.search(pattern, line_text, re.IGNORECASE)
        if m:
            return m.group(1).strip()
    return None


def extract_fields(lines):
    fields = {}
    for line in lines:
        text = line["text"]
        conf = line["avg_confidence"]
        matched_known_field = False
        for field_name, patterns in FIXED_FIELD_PATTERNS.items():
            if field_name in fields:
                continue
            value = _try_patterns(text, patterns)
            if value:
                fields[field_name] = {"value": value, "confidence": conf}
                matched_known_field = True
        for m in SUBJECT_MARK_PATTERN.finditer(text):
            subject_num, mark_value = m.group(1), m.group(2)
            key = f"subject_{subject_num}_marks"
            fields[key] = {"value": mark_value, "confidence": conf}
            matched_known_field = True
        if not matched_known_field:
            m = GENERIC_LABEL_VALUE_PATTERN.match(text)
            if m:
                raw_label, value = m.group(1), m.group(2)
                key = _normalize_label(raw_label)
                if key and key not in fields:
                    fields[key] = {"value": value.strip(), "confidence": conf}
    return fields


def fields_to_flat_dict(fields):
    return {k: v["value"] for k, v in fields.items()}
