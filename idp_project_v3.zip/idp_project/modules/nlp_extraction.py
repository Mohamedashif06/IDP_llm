"""
nlp_extraction.py
-------------------
Uses spaCy Named Entity Recognition (NER) to extract free-text fields
(mainly PERSON names) from OCR text that doesn't have a clean "Label:
Value" structure — e.g. a sentence-style document, a certificate, or a
letter, where field_extraction.py's regex approach has nothing to anchor
on.

TESTED, HONEST LIMITATION: spaCy's model is trained on normal-case
sentences. It correctly finds names in natural text ("Priya Kumar
submitted the form"), but FAILS on all-caps text ("SHIVA DHARANI P S"),
which is exactly how names are usually printed in your mark-sheet tables.
So for table/form documents, prefer field_extraction.py's labeled regex
approach — NER's real value here is genuinely free-text documents where
no explicit label exists at all. Don't reach for NER as a universal
upgrade; use it where its strength actually applies.
"""

import spacy

_nlp = None


def _get_model():
    """Loads the spaCy model once and reuses it — loading takes real time
    (100+ ms), so we don't want to reload it per-line or per-document."""
    global _nlp
    if _nlp is None:
        _nlp = spacy.load("en_core_web_sm")
    return _nlp


def extract_person_names(text: str) -> list:
    """Returns all PERSON entities spaCy finds in the given text, with a
    heuristic confidence note (spaCy doesn't give a numeric confidence for
    NER by default, so we flag ALL-CAPS input as likely-unreliable based
    on our tested finding above, rather than pretending we have a real
    confidence score)."""
    nlp = _get_model()
    doc = nlp(text)

    is_all_caps = text.isupper()
    results = []
    for ent in doc.ents:
        if ent.label_ == "PERSON":
            results.append({
                "text": ent.text,
                "reliable": not is_all_caps,  # honest flag, not a fabricated confidence number
            })
    return results


def extract_all_entities(text: str) -> dict:
    """Broader extraction — returns ALL entity types spaCy finds, grouped
    by type. Useful for free-text documents (e.g. an ID card narrative,
    a letter) where you don't know in advance which entity types will be
    present. DATE, GPE (place), ORG are the other types most likely to be
    useful for institutional documents."""
    nlp = _get_model()
    doc = nlp(text)
    grouped = {}
    for ent in doc.ents:
        grouped.setdefault(ent.label_, []).append(ent.text)
    return grouped
