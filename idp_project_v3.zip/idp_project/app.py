"""
app.py
------
Multi-photo batch pipeline: capture/upload photo 1 -> process -> confirm ->
capture/upload photo 2 -> process -> confirm -> ... -> download ONE combined
Excel file with every photo's data appended as new rows.

Two document types supported:
  "Form (Label: Value)"  - e.g. a mark sheet with "Roll No: ..." style lines
  "Table / Grid"          - e.g. your CO cycle-test sheet (dense grid table)

Run with:  streamlit run app.py
"""

import streamlit as st
import numpy as np
import cv2
from PIL import Image

from modules.preprocessing import check_image_quality, preprocess_pipeline
from modules.ocr_engine import run_ocr, group_words_into_lines
from modules.field_extraction import extract_fields
from modules.table_extractor import extract_table
from modules.excel_writer import append_record, read_all_records

st.set_page_config(page_title="IDP System — Batch Prototype", layout="wide")
st.title("📄 Intelligent Document Processing — Multi-Photo Batch Mode")

# ---------- Session state: the running batch ----------
# This is what makes "capture photo 1 -> upload -> capture photo 2 ->
# upload -> ... -> one combined Excel" work: Streamlit reruns the whole
# script on every interaction, so anything that must persist ACROSS
# multiple photo captures has to live in st.session_state, not a plain
# Python variable.
if "batch_count" not in st.session_state:
    st.session_state["batch_count"] = 0
if "excel_path" not in st.session_state:
    st.session_state["excel_path"] = "output/batch_records.xlsx"

st.sidebar.header("Batch session")
st.sidebar.metric("Photos processed this session", st.session_state["batch_count"])
excel_path = st.sidebar.text_input("Excel file (shared across all photos)", value=st.session_state["excel_path"])
st.session_state["excel_path"] = excel_path
sheet_name = st.sidebar.text_input("Sheet name", value="Records")

if st.sidebar.button("🔄 Start a NEW batch (reset counter)"):
    st.session_state["batch_count"] = 0
    st.sidebar.success("Counter reset. Excel file itself is untouched — delete it manually if you want a truly fresh file.")

st.sidebar.divider()
existing = read_all_records(excel_path, sheet_name)
st.sidebar.write(f"**Rows currently in Excel:** {len(existing)}")

doc_type = st.radio("Document type", ["Form (Label: Value lines)", "Table / Grid (dense table like a mark sheet grid)"],
                     horizontal=True)

# ---------- Step 1: Capture ----------
st.header("1. Capture or Upload THIS Photo")
input_method = st.radio("Input method", ["Upload a file", "Use camera"], horizontal=True, key="input_method")

pil_image = None
if input_method == "Upload a file":
    uploaded = st.file_uploader("Upload an image (JPG/PNG)", type=["jpg", "jpeg", "png"], key="uploader")
    if uploaded is not None:
        pil_image = Image.open(uploaded).convert("RGB")
else:
    camera_photo = st.camera_input("Take a photo of the document", key="camera")
    if camera_photo is not None:
        pil_image = Image.open(camera_photo).convert("RGB")

if pil_image is None:
    st.info("Upload or capture a document image to process it.")
    st.stop()

image_bgr = cv2.cvtColor(np.array(pil_image), cv2.COLOR_RGB2BGR)
st.image(pil_image, caption="This photo", width=350)

rotate = st.selectbox("Rotate this photo before processing (if it's sideways)", ["None", "90° clockwise", "90° counter-clockwise", "180°"])
if rotate == "90° clockwise":
    image_bgr = cv2.rotate(image_bgr, cv2.ROTATE_90_CLOCKWISE)
elif rotate == "90° counter-clockwise":
    image_bgr = cv2.rotate(image_bgr, cv2.ROTATE_90_COUNTERCLOCKWISE)
elif rotate == "180°":
    image_bgr = cv2.rotate(image_bgr, cv2.ROTATE_180)
if rotate != "None":
    st.image(cv2.cvtColor(image_bgr, cv2.COLOR_BGR2RGB), caption="Rotated", width=350)

# ---------- Step 2: Quality Check ----------
quality = check_image_quality(image_bgr)
col1, col2, col3 = st.columns(3)
col1.metric("Blur score", quality["blur_score"])
col2.metric("Brightness", quality["brightness"])
col3.metric("Usable?", "✅ Yes" if quality["is_usable"] else "❌ No")

# ---------- FORM MODE ----------
if doc_type.startswith("Form"):
    st.header("2. Preprocessing + OCR")
    steps = preprocess_pipeline(image_bgr, do_perspective=False, do_denoise=True, do_threshold=True)
    if st.button("Run OCR", type="primary"):
        result = run_ocr(steps["final"], psm=6)
        lines = group_words_into_lines(result["words"])
        st.session_state["ocr_lines"] = lines
        st.success(f"OCR confidence: {result['avg_confidence']}%")

    if "ocr_lines" in st.session_state:
        st.header("3. Extracted Fields — review before adding to batch")
        fields = extract_fields(st.session_state["ocr_lines"])
        corrected = {}
        for field_name, info in sorted(fields.items()):
            conf = info["confidence"]
            badge = "🟢" if conf >= 80 else ("🟡" if conf >= 60 else "🔴")
            corrected[field_name] = st.text_input(f"{badge} {field_name} ({conf}%)", value=info["value"])

        if st.button("➕ Add THIS photo's data to the batch Excel", type="primary"):
            summary = append_record(corrected, excel_path=excel_path, sheet_name=sheet_name)
            st.session_state["batch_count"] += 1
            st.success(f"Added as row {summary['row_written']}. Total photos processed this session: {st.session_state['batch_count']}. "
                       f"Upload/capture the NEXT photo above to continue the batch.")
            del st.session_state["ocr_lines"]  # clear so the next photo starts fresh
            st.rerun()

# ---------- TABLE MODE ----------
else:
    st.header("2. Table Extraction")
    st.caption(
        "Dense grid tables are the hardest OCR case — expect to review/correct "
        "a meaningful fraction of cells, especially alphanumeric ID columns. "
        "Name and digit columns read more reliably than mixed alphanumeric IDs."
    )
    gray = cv2.cvtColor(image_bgr, cv2.COLOR_BGR2GRAY)

    num_columns = st.number_input("Expected number of columns in this table", min_value=1, max_value=40, value=17)
    column_mode_str = st.text_input(
        "Column types, comma-separated (digits/alnum/text) — one per column, left to right",
        value="digits,alnum,alnum,text," + ",".join(["digits"] * max(0, num_columns - 4))
    )
    column_modes = [m.strip() for m in column_mode_str.split(",")]

    if st.button("Extract Table", type="primary"):
        with st.spinner("Detecting grid and reading cells — this takes longer than form OCR..."):
            table = extract_table(gray, column_modes=column_modes)
        st.session_state["extracted_table"] = table
        st.success(f"Found {len(table)} rows.")

    if "extracted_table" in st.session_state:
        st.header("3. Review extracted rows before adding to batch")
        st.caption("Edit any cell that looks wrong, then add the rows you want to keep.")
        table = st.session_state["extracted_table"]

        # Let the user pick which row range is actual DATA (headers/title
        # rows at the top will usually need to be skipped)
        start_row = st.number_input("First data row index (0-based) — skip header/title rows above this", min_value=0, max_value=max(0, len(table)-1), value=0)
        end_row = st.number_input("Last data row index (inclusive)", min_value=0, max_value=max(0, len(table)-1), value=min(5, len(table)-1))

        edited_rows = []
        for i in range(start_row, min(end_row + 1, len(table))):
            row = table[i]
            cols = st.columns(len(row))
            edited_row = []
            for j, cell_val in enumerate(row):
                edited_row.append(cols[j].text_input(f"r{i}c{j}", value=cell_val, label_visibility="collapsed", key=f"cell_{i}_{j}"))
            edited_rows.append(edited_row)

        if st.button("➕ Add these rows to the batch Excel", type="primary"):
            added = 0
            for row in edited_rows:
                record = {f"col_{i}": val for i, val in enumerate(row)}
                append_record(record, excel_path=excel_path, sheet_name=sheet_name)
                added += 1
            st.session_state["batch_count"] += 1
            st.success(f"Added {added} row(s) from this photo. Total photos processed this session: {st.session_state['batch_count']}. "
                       f"Upload/capture the NEXT photo above to continue.")
            del st.session_state["extracted_table"]
            st.rerun()

# ---------- Batch summary + download (always visible) ----------
st.divider()
st.header("📊 Current Batch Excel Contents")
existing_records = read_all_records(excel_path, sheet_name)
if existing_records:
    st.write(f"**{len(existing_records)} total row(s)** across **{st.session_state['batch_count']} photo(s)** processed this session.")
    st.dataframe(existing_records, use_container_width=True)
    with open(excel_path, "rb") as f:
        st.download_button("⬇️ Download combined Excel file", f, file_name=excel_path.split("/")[-1], type="primary")
else:
    st.info("No rows saved yet — process a photo above and add it to the batch.")
